import SILSandbox from "@/components/SILSandbox";

const Index = () => {
  return <SILSandbox />;
};

export default Index;
